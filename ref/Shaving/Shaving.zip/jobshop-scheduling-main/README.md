**Jobshop-scheduling** is a Python library for job-shop scheduling problem published by [tkp0331](https://github.com/tkp0331).   
This library consists of implementation of previous theses.   

## Implemented theses
### Shaving
1. Carlier, J., and Pinson, E. (1994), "Adjustments of heads and tails
for the job-shop problem', *European Journal of Operational
Research* 78, 146-161.
