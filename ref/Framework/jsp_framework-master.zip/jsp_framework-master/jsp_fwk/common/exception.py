class JSPException(Exception):
    pass